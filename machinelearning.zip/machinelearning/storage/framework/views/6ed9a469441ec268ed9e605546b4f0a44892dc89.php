<!DOCTYPE html>

<html lang="en">


  <head>

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">

    <title>:: Machine Learning : Rating of Cereal</title>



    <!-- style -->

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Bootstrap -->

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- carousel -->

    <link href="<?php echo e(asset('css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css">

    <!-- responsive -->

    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet" type="text/css">

    <!-- font-awesome -->

    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- font-awesome -->

    <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('css/popup.css')); ?>" rel="stylesheet" type="text/css">

  </head>

   <body class="module-home" data-spy="scroll" data-target=".navbar">



	<!-- header -->

    	<header role="header" class="header-top" id="headere-top">



        	<div class="header-fixed-wrapper" role="header-fixed">

                <div class="container">

                    <!-- hgroup -->

                    <hgroup class="row">

                        <!-- logo -->

                        <div class="col-xs-5 col-sm-2 col-md-2 col-lg-2">

                            <h2>

                                ML

                            </h2>

                        </div>

                        <!-- logo -->

                        <!-- nav -->

                        <nav role="navigation" class="col-xs-12 col-sm-10 col-md-10 col-lg-10 navbar navbar-default">

                            <div class="navbar-header">

                                <button type="button" id="predict" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                                    <span class="sr-only">Toggle navigation</span>

                                    <span class="icon-bar"></span>

                                    <span class="icon-bar"></span>

                                    <span class="icon-bar"></span>

                                </button>

                            </div>

                            <div id="navbar" class="navbar-collapse collapse">

                                <ul class="nav navbar-nav">

                                    <li class="active"><a href="<?php echo e(url('/')); ?>" title="Home">Home</a></li>

                                    <li><a href="#section-six" title="Prediction">Prediction</a></li>

                                </ul>

                            </div>

                        </nav>

                        <!-- nav -->

                    </hgroup>

                    <!-- hgroup -->

                  </div>

            </div>

            <!-- banner Text -->

                 <section class="text-center">
                        <body background="backgroundImage.png">
                                <h2>Machine Learning Prediction</h2>


                                <a  href="#section-six" class="button-header">Get Strated</a>
                            </body>
                </section>



            <!-- banner Text -->



            <!-- banner image -->

        	<figure>

            	<div class="parallax-window item tp-banner-container" data-parallax="scroll" data-image-src="images/backgroundImage.png"></div>

            </figure>

            <!-- banner image -->

        </header>

    <!-- header -->



    <!-- main -->

    	<main role="main" id=" main-wrapper">

        	     	<!-- top pan -->


            <!-- section-six -->

            <section class="section-six" id="section-six">

            	<div class="container">

                	 <header role="title-page" class="text-center">

                        <h4>Get your predict Now !!</h4>

                    </header>

                    <!-- contact-form -->

                    <div class="contact-form">

                            <form method="post" action="<?php echo e(url('/result')); ?>" name="cform" id="cform">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">

                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 2px">
                                        <input  name="calories" id="calories" type="text" placeholder="Calories">
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 2px">
                                            <input  name="potass" id="potass" type="text" placeholder="Potass">
                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 5px">
                                        <input  name="carbo" id="carbo" type="text"  placeholder="Carbohidrat">
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 5px">
                                            <input  name="sodium" id="sodium" type="text" placeholder="Sodium">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 5px">
                                            <input  name="fat" id="fat" type="text"  placeholder="Fat">
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 5px">
                                            <input  name="protein" id="protein" type="text" placeholder="Proteins">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 5px">
                                            <input  name="fiber" id="fiber" type="text"  placeholder="Fiber">
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6" style="padding-top: 5px">
                                            <input  name="vitamins" id="vitamins" type="text" placeholder="Vitamins">
                                    </div>
                                </div>

                                  <br>
                                  <br>
                                  <p style="text-align:center">Your Cereal Ratings:</p>


                                <input  name="tmpresult" class="col-md-4 col-lg-4 col-sm-4" size="12" style="align:center" type="text" id="tmpresult2">





                                <div class="clearfix"></div>

                                <input name="" type="submit" value="Predict">

                                <div id="simple-msg"></div>

                        </form>

                     </div>

                    <!-- contact-form -->

                    <div class="clearfix"></div>

                </div>
            </section>

            <!-- section-six -->

            <!-- section-seven -->

            <section class="section-seven" id="section-seven">

            </section>



           <!-- footer -->

           <footer role="footer" class="footer text-center">

           		<div class="container">

                	<!-- socil-icons -->

                	<section role="socil-icons" class="socil-icons">

                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>

                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>

                        <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>

                        <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>

                        <a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a>

                        <a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a>

                    </section>

                    <!-- socil-icons -->

                    <!-- nav -->

                    <nav role="footer-nav">

                        <a href="#">Terms of Use </a>

                        <a href="#">Privacy Policy</a>

                    </nav>

                    <!-- nav -->

                    <p class="copy">&copy; 2016 Sartr. All rights reserved. Made with <i class="fa fa-heart pulse"></i> by <a href="http://www.designstub.com/">Designstub</a></p>

                </div>

           </footer>

           <!-- footer -->



        </main>

    <!-- main -->





    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <script src="js/jquery.min.js" type="text/javascript"></script>



	<script src="js/parallax.min.js" type="text/javascript"></script>

	<script type="text/javascript">

    	$('.parallax-window').parallax({});

    </script>

    <script src="<?php echo e(asset('js/main.js')); ?>" type="text/javascript"></script>

	<script src="js/owl.carousel.js" type="text/javascript"></script>

    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>

	<script src="js/maps.js" type="text/javascript"></script>

    <script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>

	<script type="text/javascript" src="js/video.js"></script>

    <script src="js/custom.js" type="text/javascript"></script>

	<script src="js/jquery.magnific-popup.min.js" type="text/javascript"></script>

	<script src="js/jquery.contact.js" type="text/javascript"></script>

    <script src="js/bootstrap.min.js" type="text/javascript"></script>

	<script src="js/html5shiv.min.js" type="text/javascript"></script>
  <script src="https://code.jquery.com/jquery-1.8.0.min.js"></script>
         <script type="text/javascript">
           $(document).ready(function(){
             $.ajaxSetup({
 	          headers: {
 		            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   	         }
             });
             $('#cform').submit(function(e){
               e.preventDefault();

               var calories=$('#calories').val();
               var carbo=$('#carbo').val();
               var fat=$('#fat').val();
               var fiber=$('#fiber').val();
               var potass=$('#potass').val();
               var protein=$('#protein').val();
               var sodium=$('#sodium').val();
               var vitamins=$('#vitamins').val();
               /*$.get('predict',function(data){
                 $('#predictData').append(data);
                 console.log(data);
               });*/
               $.ajax({
                 type: "POST",
                 url:"https://tugasbesarcereal.herokuapp.com/predict/task",
                 data:'{"calories":'+calories+',"carbo":'+carbo+',"fat":'+fat+',"fiber":'+fiber+',"potass":'+potass+',"protein":'+protein+',"sodium":'+sodium+',"vitamins":'+vitamins+'}',
                 contentType: 'application/json; charset=utf-8',
                 dataType: "json",
                 success:function(data){
                   console.log(data);
                   var dataTemp=data['message'];
                   $('#tmpresult').append(dataTemp);
                   $('#tmpresult2').val(dataTemp);
                 }
               });
             });
           });
         </script>


  </body>

</html>
